function [S_sp]  = Sphere(X_sp_c,Y_sp_c,Z_sp_c,R_sp,theta_abs,psi_abs,phi_abs)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

global TI; global TJ; global TK;

%%%%%%%%%%%%%%%% Voxelization %%%%%%%%%%%%%%%%%%%%%%%%%%%%

dcm = Rotation_Center(theta_abs,psi_abs,phi_abs);

Center = [X_sp_c Y_sp_c Z_sp_c]*dcm;

S_sp = (TI-Center(1)).^2+(TJ-Center(2)).^2+(TK-Center(3)).^2 <= R_sp^2;


end

