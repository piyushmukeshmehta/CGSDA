function [S_cy] = Cylinder(L_cy,D_cy,theta_cy_rel,psi_cy_rel,phi_cy_rel,X_cy_c,Y_cy_c,Z_cy_c,theta_abs,psi_abs,phi_abs)  

% ##################### Credits ################################

% Prototype Version 1.0, created by
% Piyush Mukesh Mehta on 15 Dec, 2015
 
% For Questions, please contact the author @
% piyushmukeshmehta@gmail.com

% Please give appropriate credit for any use or modifications of this
% version.

% Please Cite: Mehta et al., Computer Graphics for Space Debris, ICATT,
% Darmstadt, Germany, 2015.

% #############################################################

global TI; global TJ; global TK;

%%%%%%%%%%%%%%%% Voxelization %%%%%%%%%%%%%%%%%%%%%%%%%%%%

[X1_cy_rel,Y1_cy_rel,Z1_cy_rel,X2_cy_rel,Y2_cy_rel,Z2_cy_rel] = Rotation_Axis_Cylinder( theta_cy_rel, psi_cy_rel, phi_cy_rel, L_cy );

dcm = Rotation_Center(theta_abs,psi_abs,phi_abs);

Point1 = [X1_cy_rel,Y1_cy_rel,Z1_cy_rel] * dcm;
Point2 = [X2_cy_rel,Y2_cy_rel,Z2_cy_rel] * dcm;
Center = [X_cy_c Y_cy_c Z_cy_c]*dcm;

Point1 = Point1 + Center;
Point2 = Point2 + Center;

% a = Point2 - Point1;
% b1 = Point1(1) - TI.*1;
% b2 = Point1(2) - TJ.*1;
% b3 = Point1(3) - TK.*1;
% 
% t = -(b1.*a(1)+b2.*a(2)+b3.*a(3))/norm(a);
% d_x = b1 + a(1) * t;
% d_y = b2 + a(2) * t;
% d_z = b3 + a(3) * t;
% 
% dist = sqrt(d_x.*d_x + d_y.*d_y + d_z.*d_z);
% 
% d_cy_1 = a(1)*Point1(1) + a(2)*Point1(2) + a(3)*Point1(3);          %Starting plane of the Cylinder ax + by + cz = d
% d_cy_2 = a(1)*Point2(1) + a(2)*Point2(2) + a(3)*Point2(3);          %Starting plane of the Cylinder ax + by + cz = d
% 
% min_d = min(d_cy_1,d_cy_2);
% max_d = max(d_cy_1,d_cy_2);
% 
% Temp_cy_1 = TI.*a(1)+TJ.*a(2)+TK.*a(3);
% 
% R_cy = 0.5 * D_cy;
% 
% S_cy = dist.*1 <= R_cy & (min_d < Temp_cy_1) & (Temp_cy_1 < max_d);

X1_cy = Point1(1);
Y1_cy = Point1(2);
Z1_cy = Point1(3);
X2_cy = Point2(1);
Y2_cy = Point2(2);
Z2_cy = Point2(3);

Temp1 = TI - X1_cy; 
Temp2 = TJ - Y1_cy;
Temp3 = TK - Z1_cy;

Temp21 = TI - X2_cy; 
Temp22 = TJ - Y2_cy;
Temp23 = TK - Z2_cy;

Temp_Cross1 =   (Temp2.*Temp23 - Temp22.*Temp3);
Temp_Cross2 = - (Temp1.*Temp23 - Temp21.*Temp3);
Temp_Cross3 =   (Temp1.*Temp22 - Temp21.*Temp2);

Temp_diff_X = X2_cy-X1_cy;
Temp_diff_Y = Y2_cy-Y1_cy;
Temp_diff_Z = Z2_cy-Z1_cy;

d_cy_1 = (Temp_diff_X)*X1_cy + (Temp_diff_Y)*Y1_cy + (Temp_diff_Z)*Z1_cy;          %Starting plane of the Cylinder ax + by + cz = d
d_cy_2 = (Temp_diff_X)*X2_cy + (Temp_diff_Y)*Y2_cy + (Temp_diff_Z)*Z2_cy;          %Starting plane of the Cylinder ax + by + cz = d

Temp_cy_1 = TI.*(Temp_diff_X)+TJ.*(Temp_diff_Y)+TK.*(Temp_diff_Z);

R_cy = 0.5 * D_cy;
Temp_norm = norm ([Temp_diff_X, Temp_diff_Y, Temp_diff_Z]);
min_d = min(d_cy_1,d_cy_2);
max_d = max(d_cy_1,d_cy_2);

S_cy = ((Temp_Cross1.*Temp_Cross1 + Temp_Cross2.*Temp_Cross2 + Temp_Cross3.*Temp_Cross3) / Temp_norm^2 <= (R_cy)^2) ...
    & (min_d < Temp_cy_1) & (Temp_cy_1 < max_d);


end

