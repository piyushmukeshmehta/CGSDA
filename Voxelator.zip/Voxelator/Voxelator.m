%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                                       %
%                                                                                       %
%                                       Voxelator                                       %
%                                                                                       %
%                                              created by Piyush M. Mehta, Dec 1 2015   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% JSK

% Prototype Version 1.0, created by
% Piyush Mukesh Mehta on Dec 1, 2015

% The tool is developed for quick estimation of aerodynamics and
% aerothermodynamics of re-entering objects. The tool uses state-of-the-art 
% graphical technique of using voxel to create the deisred geometery. The geometry 
% is made using a combination of primitives (current version models only sphere,
% cube, cylinder, and cone). For details about the tool,
% please read 

% Piyush M. Mehta, Gonzalo Blanco-Arnao, Davide Bonetti, et al., 
% Computer Graphics for Space Debris, 6th International Conference on 
% Astrodynamics Tools and Techniques, Darmstadt, Germany, 14-17 March, 2016.

% Distributed under terms of GNU General Public License. Please see
% Copyright file in the directory

% Inputs: 1) .csv file with information about size, relative and abolute
%            location as well as relative orientations
%         2) viewing direction (see string variable 'Direction')
%         3) User defined domain or grid resolution (resolution ratio,
%         pixels per unit length)
%         4) Absolute orientation of the geometry
%
% Outputs: Visiblity factors for each primitive used in creating the
% geometry. Read the paper to learn about how to use them

% If you use Pixelator in any program or publication, please acknowledge
% its authors by adding a reference to: Piyush M. Mehta, Gonzalo Blanco-Arnao, Davide Bonetti, et al., 
% Computer Graphics for Space Debris, 6th International Conference on Astrodynamics Tools and Techniques,
% Darmstadt, Germany, 14-17 March, 2016.

% You can contact the author at piyushmukeshmehta@gmail.com for any
% questions or comments.

clear all
clc
clf

tic()

% Note: To put a cone point towards negative X, set yaw = 180 and not
% pitch.

%%%%%%%%%%%%%%%%%%%%%%%%%% User Inputs %%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 1)

% Definition of primities inside the geometry file uses the following
% order
% Sphere = 1, Cube = 2, Cylinder = 3, Cone = 4. 

% Name of the Geometry
Geometry = 'Upper_Stage';

% Geometry Path
% Make sure a geometry definition file exists inside the directory
Geoms = csvread(['./Geometries/' Geometry '/' Geometry '.csv']);

% Rescaling and repositioning the geometry
% If the geometry is not unit scaled and positioned correctly in the 
% geometry file, you can do so as shown below.
% If the geometry is not fully contained in the domain, matlab will throw
% an error
if strcmp(Geometry,'Deimos_2');
Geoms(:,2:5) = Geoms(:,2:5)/96;
Geoms(:,2) = Geoms(:,2) + 0.2;
end

% 2)

% Viewing Direction
Direction = 'Negative';         % Direction for Projection, Negative looks along the negative direction for all axes

% 3)

% Defining the Domain and Grid Resolution (resolution ratio)
% If the geometry is not fully contained in the domain, matlab will throw
% an error
e = 50;     % Number of Voxel in each dimension
Max_Dim = 1.5;     % Maximum Size of the cubic domain
Ratio_Res = e/Max_Dim;  % Resolution Ratio, Voxels per unit length

% Generating the grid for voxelizing the primitives and overall geometry
t = linspace(-Max_Dim,Max_Dim,e);
global TI; global TJ; global TK; global Output; global S;
[TI,TJ,TK] = ndgrid(t,t,t);

% 4)

% Absolute Orientation of the geometry
View_Angle = [0 170 30];    %[Phi_abs Theta_abs Psi_abs]


% Reads in the primitives inside the geometry file 
nSphere = 0;
nCube = 0;
nCylinder = 0;
nCone = 0;

for i = 1:length(Geoms(:,1));
    
    switch Geoms(i,1)
        
        case {1}
            
            Input.(['Sphere' num2str(nSphere)]).type = 'Sphere';      %Center
            Input.(['Sphere' num2str(nSphere)]).center = [Geoms(i,2) Geoms(i,3) Geoms(i,4)];
            Input.(['Sphere' num2str(nSphere)]).radius = Geoms(i,5);
            
            nSphere = nSphere + 1;
            
        case {2}
            
            Input.(['Cube' num2str(nCube)]).type = 'Cube';
            Input.(['Cube' num2str(nCube)]).center = [Geoms(i,2) Geoms(i,3) Geoms(i,4)];        %Center
            Input.(['Cube' num2str(nCube)]).height = Geoms(i,5);      % Z length
            Input.(['Cube' num2str(nCube)]).length_height = Geoms(i,6);     % X/Y ratio
            Input.(['Cube' num2str(nCube)]).width_height = Geoms(i,7);    % Y/Z ratio
            Input.(['Cube' num2str(nCube)]).roll = Geoms(i,8);      % Phi, degrees
            Input.(['Cube' num2str(nCube)]).pitch = Geoms(i,9);      % Theta, degrees
            Input.(['Cube' num2str(nCube)]).yaw = Geoms(i,10);      % Psi, degrees
            
            nCube = nCube + 1;
                
        case {3}
            
            Input.(['Cylinder' num2str(nCylinder)]).type = 'Cylinder';
            Input.(['Cylinder' num2str(nCylinder)]).center = [Geoms(i,2) Geoms(i,3) Geoms(i,4)];        % Center
            Input.(['Cylinder' num2str(nCylinder)]).diameter = Geoms(i,5);      % Diameter
            Input.(['Cylinder' num2str(nCylinder)]).length_diameter = Geoms(i,6);     % Length to Diameter ratio
            Input.(['Cylinder' num2str(nCylinder)]).roll = Geoms(i,7);      % Phi, degrees
            Input.(['Cylinder' num2str(nCylinder)]).pitch = Geoms(i,8);      % Theta, degrees
            Input.(['Cylinder' num2str(nCylinder)]).yaw = Geoms(i,9);      % Psi, degrees
            
            nCylinder = nCylinder + 1;
                    
        case {4}
            
            Input.(['Cone' num2str(nCone)]).type = 'Cone';
            Input.(['Cone' num2str(nCone)]).center = [Geoms(i,2) Geoms(i,3) Geoms(i,4)];        % Barycenter
            Input.(['Cone' num2str(nCone)]).diameter = Geoms(i,5);      % Diameter
            Input.(['Cone' num2str(nCone)]).length_diameter = Geoms(i,6);     % Length to Diameter ratio
            Input.(['Cone' num2str(nCone)]).roll = Geoms(i,7);      % Phi, degrees
            Input.(['Cone' num2str(nCone)]).pitch = Geoms(i,8);      % Theta, degrees
            Input.(['Cone' num2str(nCone)]).yaw = Geoms(i,9);      % Psi, degrees
            
            nCone = nCone + 1;
    end
    
end


% Initializing the Loop and Preallocating 

fieldList = fieldnames(Input);
Dimension = size(TI);
Output = zeros(Dimension(1),Dimension(2),Dimension(3),length(fieldList),'uint8');
Ratio_X = zeros(length(fieldList),1); Ratio_Y = zeros(length(fieldList),1); Ratio_Z = zeros(length(fieldList),1);
Area_X = zeros(length(fieldList),1); Area_Y = zeros(length(fieldList),1); Area_Z = zeros(length(fieldList),1);

% Voxelizing primitives and adding them to the domain

for i = 1:length(fieldList)
    type = Input.(fieldList{i}).type;
    
    switch type
        case {'Sphere' 'sphere'}
            
            S_sp = Sphere(Input.(fieldList{i}).center(1),Input.(fieldList{i}).center(2), ...
                Input.(fieldList{i}).center(3), Input.(fieldList{i}).radius, View_Angle(2), View_Angle(3), View_Angle(1));
        
            Output(:,:,:,i) = S_sp*i;
            
        case {'Cube' 'cube'}
            
            S_cu = Cube(Input.(fieldList{i}).height*Input.(fieldList{i}).length_height, ...
                Input.(fieldList{i}).height*Input.(fieldList{i}).width_height, ...
                Input.(fieldList{i}).height,Input.(fieldList{i}).pitch, ...
                Input.(fieldList{i}).yaw,Input.(fieldList{i}).roll, ...
                Input.(fieldList{i}).center(1),Input.(fieldList{i}).center(2), ...
                Input.(fieldList{i}).center(3), View_Angle(2), View_Angle(3), View_Angle(1));
        
            Output(:,:,:,i) = S_cu*i;
        
        case {'Cylinder' 'cylinder'}

            S_cy = Cylinder(Input.(fieldList{i}).diameter*Input.(fieldList{i}).length_diameter, ...
                Input.(fieldList{i}).diameter,Input.(fieldList{i}).pitch, ...
                Input.(fieldList{i}).yaw,Input.(fieldList{i}).roll, ...
                Input.(fieldList{i}).center(1),Input.(fieldList{i}).center(2), ...
                Input.(fieldList{i}).center(3), View_Angle(2), View_Angle(3), View_Angle(1));

            Output(:,:,:,i) = S_cy*i;
            
        case {'Cone' 'cone'}

            S_cn = Cone(Input.(fieldList{i}).diameter*Input.(fieldList{i}).length_diameter, ...
                Input.(fieldList{i}).diameter,Input.(fieldList{i}).pitch, ...
                Input.(fieldList{i}).yaw,Input.(fieldList{i}).roll, ...
                Input.(fieldList{i}).center(1),Input.(fieldList{i}).center(2), ...
                Input.(fieldList{i}).center(3), View_Angle(2), View_Angle(3), View_Angle(1));
            
            Output(:,:,:,i) = S_cn*i;
        
        otherwise
            
            error ('No geometry recognised!!')
    end
    
    Check_non_zero = any(Output(:,:,:,i));
    if Check_non_zero == 0
        
        error('Please check resolution!!. Recommend increasing resolution');
        
    end
    
    [Ratio_X(i),Ratio_Y(i),Ratio_Z(i)] = Projection(i);
   
end

S = sum(Output,4);

% Computing the visilibity factors

[VF_X, VF_Y, VF_Z] = Ray_Trace(fieldList,Ratio_X,Ratio_Y,Ratio_Z,Direction);

toc()

% Only for Visualization

figure(1)
[xx,yy,zz] = meshgrid(t,t,t);
id1 = 0;

for ij = 1:length(fieldList)

id= find(S == ij);
id1 = [id1; id];

plot3(xx(id),yy(id),zz(id),'Color',rand(1,3),'Marker','o')
hold on

end

id1 = id1(2:end,1);
plot3(xx(id1)*0+min(xx(:)),yy(id1),zz(id1),'ko')
hold on
plot3(xx(id1),yy(id1)*0+min(yy(:)),zz(id1),'bo')
hold on
plot3(xx(id1),yy(id1),zz(id1)*0+min(zz(:)),'ro')

set(gcf,'color','w');

camup([0 0 -1]);
view(View_Angle)

axis equal, grid on

xlim([-Max_Dim Max_Dim]);
ylim([-Max_Dim Max_Dim]);
zlim([-Max_Dim Max_Dim]);

xlabel('Y','fontsize',24);
ylabel('X','fontsize',24);
zlabel('Z','fontsize',24);

set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])
set(gca,'ZTickLabel',[])

