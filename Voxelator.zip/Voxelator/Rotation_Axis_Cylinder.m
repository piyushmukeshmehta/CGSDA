function [ X1, Y1, Z1, X2, Y2, Z2] = Rotation_Axis_Cylinder( theta, psi, phi, L )

% ##################### Credits ################################

% Prototype Version 1.0, created by
% Piyush Mukesh Mehta on 15 Dec, 2015
 
% For Questions, please contact the author @
% piyushmukeshmehta@gmail.com

% Please give appropriate credit for any use or modifications of this
% version.

% Please Cite: Mehta et al., Computer Graphics for Space Debris, ICATT,
% Darmstadt, Germany, 2015.

% #############################################################

UVec = [1 0 0];
% dcm = [cosd(theta)*cosd(psi)    cosd(phi)*sind(psi)+sind(phi)*sind(theta)*cosd(psi)     sind(phi)*sind(psi)-cosd(phi)*sind(theta)*cosd(psi); ...
%       -cosd(theta)*sind(psi)    cosd(phi)*cosd(psi)-sind(phi)*sind(theta)*sind(psi)     sind(phi)*cosd(psi)+cosd(phi)*sind(theta)*sind(psi); ...
%        sind(theta)             -sind(phi)*cosd(theta)                                   cosd(phi)*cosd(theta)];
   
   dcm = [cosd(theta)*cosd(psi) cosd(theta)*sind(psi) -sind(theta); ...
       -cosd(phi)*sind(psi)+sind(phi)*sind(theta)*cosd(psi) sind(phi)*sind(theta)*sind(psi)+cosd(phi)*cosd(psi) sind(phi)*cosd(theta); ...
       cosd(phi)*sind(theta)*cosd(psi)+sind(phi)*sind(psi) cosd(phi)*sind(theta)*sind(psi)-sind(phi)*cosd(psi) cosd(phi)*cosd(theta)];
   
Axis = UVec * dcm;
Axis1 = -UVec * dcm;

X1 = 0.5 * L * Axis1(1);
Y1 = 0.5 * L * Axis1(2);
Z1 = 0.5 * L * Axis1(3);

X2 = 0.5 * L * Axis(1);
Y2 = 0.5 * L * Axis(2);
Z2 = 0.5 * L * Axis(3);

end

