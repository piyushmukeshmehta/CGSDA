function [S_cu]  = Cube(Len_cu,Wid_cu,Hei_cu,theta_cu_rel,psi_cu_rel,phi_cu_rel,X_cu_c,Y_cu_c,Z_cu_c,theta_abs,psi_abs,phi_abs)

% ##################### Credits ################################

% Prototype Version 1.0, created by
% Piyush Mukesh Mehta on 15 Dec, 2015
 
% For Questions, please contact the author @
% piyushmukeshmehta@gmail.com

% Please give appropriate credit for any use or modifications of this
% version.

% Please Cite: Mehta et al., Computer Graphics for Space Debris, ICATT,
% Darmstadt, Germany, 2015.

% #############################################################

global TI; global TJ; global TK;

%%%%%%%%%%%%%%%% Voxelization %%%%%%%%%%%%%%%%%%%%%%%%%%%%

A_Cu = [ 0.5*Len_cu          0.5*Wid_cu         0.5*Hei_cu];
B_Cu = [ 0.5*Len_cu          0.5*Wid_cu        -0.5*Hei_cu];
C_Cu = [-0.5*Len_cu          0.5*Wid_cu        -0.5*Hei_cu];
D_Cu = [-0.5*Len_cu          0.5*Wid_cu         0.5*Hei_cu];
E_Cu = [ 0.5*Len_cu         -0.5*Wid_cu         0.5*Hei_cu];
F_Cu = [ 0.5*Len_cu         -0.5*Wid_cu        -0.5*Hei_cu];
G_Cu = [-0.5*Len_cu         -0.5*Wid_cu        -0.5*Hei_cu];
H_Cu = [-0.5*Len_cu         -0.5*Wid_cu         0.5*Hei_cu];

P_Cu = [A_Cu;B_Cu;C_Cu;D_Cu;E_Cu;F_Cu;G_Cu;H_Cu];

dcm_cu_rel = Rotation_Center(theta_cu_rel,psi_cu_rel,phi_cu_rel);
P_Cu = P_Cu*dcm_cu_rel;

dcm_abs = Rotation_Center(theta_abs,psi_abs,phi_abs);
P_Cu = P_Cu*dcm_abs;

Center = [X_cu_c Y_cu_c Z_cu_c]*dcm_abs;

P_Cu(:,1) = P_Cu(:,1) + Center(1);
P_Cu(:,2) = P_Cu(:,2) + Center(2);
P_Cu(:,3) = P_Cu(:,3) + Center(3);

%%%%%%%%%% http://geomalgorithms.com/a08-_containers.html

Plane1 = cross(P_Cu(2,:)-P_Cu(1,:),P_Cu(4,:)-P_Cu(1,:));        %X-Z plane
Plane2 = cross(P_Cu(5,:)-P_Cu(1,:),P_Cu(2,:)-P_Cu(1,:));        %X-Y plane
Plane3 = cross(P_Cu(4,:)-P_Cu(1,:),P_Cu(5,:)-P_Cu(1,:));        %Y-Z plane

DX1 = dot(Plane1,P_Cu(1,:));
DX2 = dot(Plane1,P_Cu(7,:));
DY1 = dot(Plane2,P_Cu(1,:));
DY2 = dot(Plane2,P_Cu(7,:));
DZ1 = dot(Plane3,P_Cu(1,:));
DZ2 = dot(Plane3,P_Cu(7,:));

Temp_cu_1 = TI.*Plane1(1)+TJ.*Plane1(2)+TK.*Plane1(3);
Temp_cu_2 = TI.*Plane2(1)+TJ.*Plane2(2)+TK.*Plane2(3);
Temp_cu_3 = TI.*Plane3(1)+TJ.*Plane3(2)+TK.*Plane3(3);

S_cu = (min(DX1,DX2) < Temp_cu_1) & (Temp_cu_1 < max(DX1,DX2)) ...
     & (min(DY1,DY2) < Temp_cu_2) & (Temp_cu_2 < max(DY1,DY2)) ...
     & (min(DZ1,DZ2) < Temp_cu_3) & (Temp_cu_3 < max(DZ1,DZ2));

end

