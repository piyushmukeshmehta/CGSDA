function [S_cn] = Cone(L_cn,D_cn,theta_cn_rel,psi_cn_rel,phi_cn_rel,X_cn_c,Y_cn_c,Z_cn_c,theta_abs,psi_abs,phi_abs) 

% ##################### Credits ################################

% Prototype Version 1.0, created by
% Piyush Mukesh Mehta on 15 Dec, 2015
 
% For Questions, please contact the author @
% piyushmukeshmehta@gmail.com

% Please give appropriate credit for any use or modifications of this
% version.

% Please Cite: Mehta et al., Computer Graphics for Space Debris, ICATT,
% Darmstadt, Germany, 2015.

% #############################################################

global TI; global TJ; global TK;

%%%%%%%%%%%%%%%% Voxelization %%%%%%%%%%%%%%%%%%%%%%%%%%%%

[X1_cn_rel,Y1_cn_rel,Z1_cn_rel,X2_cn_rel,Y2_cn_rel,Z2_cn_rel] = Rotation_Axis_Cone( theta_cn_rel, psi_cn_rel, phi_cn_rel, 0, 0, 0, L_cn );

dcm = Rotation_Center(theta_abs,psi_abs,phi_abs);

Point1 = [X1_cn_rel,Y1_cn_rel,Z1_cn_rel] * dcm;
Point2 = [X2_cn_rel,Y2_cn_rel,Z2_cn_rel] * dcm;
Center = [X_cn_c Y_cn_c Z_cn_c]*dcm;

Point1 = Point1 + Center;
Point2 = Point2 + Center;

X1_cn = Point1(1);
Y1_cn = Point1(2);
Z1_cn = Point1(3);
X2_cn = Point2(1);
Y2_cn = Point2(2);
Z2_cn = Point2(3);

% dcm_center = Rotation_Center(theta_abs,psi_abs,phi_abs);
% Center = [X_cn_c Y_cn_c Z_cn_c]*dcm_center;

d_cn_1 = (X2_cn-X1_cn)*X1_cn + (Y2_cn-Y1_cn)*Y1_cn + (Z2_cn-Z1_cn)*Z1_cn;          %Starting plane of the Cylinder ax + by + cz = d
d_cn_2 = (X2_cn-X1_cn)*X2_cn + (Y2_cn-Y1_cn)*Y2_cn + (Z2_cn-Z1_cn)*Z2_cn;          %Starting plane of the Cylinder ax + by + cz = d

Temp_cn_1 = Y2_cn-Y1_cn;
Temp_cn_2 = X2_cn-X1_cn;
Temp_cn_3 = Z2_cn-Z1_cn;

Alpha_cn = atan2(D_cn/2,L_cn)*180/pi;
S_cn = ((((Temp_cn_1).^2 + (Temp_cn_2).^2 + (Temp_cn_3).^2) * ((TJ-Y1_cn).^2 + (TI-X1_cn).^2 + (TK-Z1_cn).^2) * cosd(Alpha_cn)^2 - ...
    ((TI-X1_cn).*(Temp_cn_2)+(TJ-Y1_cn).*(Temp_cn_1)+(TK-Z1_cn).*(Temp_cn_3)).*((TI-X1_cn).*(Temp_cn_2)+(TJ-Y1_cn).*(Temp_cn_1)+(TK-Z1_cn).*(Temp_cn_3))) <= 0) ...
    & (min(d_cn_1,d_cn_2) < (TI.*(Temp_cn_2)+TJ.*(Temp_cn_1)+TK.*(Temp_cn_3))) & ((TI.*(Temp_cn_2)+TJ.*(Temp_cn_1)+TK.*(Temp_cn_3)) < max(d_cn_1,d_cn_2));      % Vertex at (a,b,c) opening in the z-direction


end

