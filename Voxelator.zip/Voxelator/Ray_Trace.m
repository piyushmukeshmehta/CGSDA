function [SF_X, SF_Y, SF_Z] = Ray_Trace(fieldList,Ratio_X,Ratio_Y,Ratio_Z,Direction)

% ##################### Credits ################################

% Prototype Version 1.0, created by
% Piyush Mukesh Mehta on 15 Dec, 2015
 
% For Questions, please contact the author @
% piyushmukeshmehta@gmail.com

% Please give appropriate credit for any use or modifications of this
% version.

% Please Cite: Mehta et al., Computer Graphics for Space Debris, ICATT,
% Darmstadt, Germany, 2015.

% #############################################################

global S;

switch Direction
    
    case {'Negative' 'negative'}
        Dir = 'last';
        
    case {'Positive' 'positive'}
        Dir = 'first';
end

Size = size(S);

%%%%%%%%% Along X %%%%%%%%%%%%%

YY = 1:Size(2);
ZZ = 1:Size(3);

YY = repmat(YY,1,Size(3));
YY = sortrows(YY');
ZZ = repmat(ZZ,1,Size(2))';

S_New_X = zeros(Size(2),Size(3));

for ii = 1:length(YY);
    Vector = S(:,YY(ii),ZZ(ii));
    K_X = find(Vector,1,Dir);
    K_V_X = Vector(K_X);
    Check = isempty(K_V_X);
    if Check == 1;
        S_New_X(YY(ii),ZZ(ii)) = 0;
    else
        S_New_X(YY(ii),ZZ(ii)) = K_V_X;
    end
end

%%%%%%%%% Along Y %%%%%%%%%%%%%

XX = 1:Size(1);
ZZ = 1:Size(3);

XX = repmat(XX,1,Size(3));
XX = sortrows(XX');
ZZ = repmat(ZZ,1,Size(1))';

S_New_Y = zeros(Size(1),Size(3));

for ii = 1:length(XX);
    Vector = S(XX(ii),:,ZZ(ii));
    K_Y = find(Vector,1,Dir);
    K_V_Y = Vector(K_Y);
    Check = isempty(K_V_Y);
    if Check == 1;
        S_New_Y(XX(ii),ZZ(ii)) = 0;
    else
        S_New_Y(XX(ii),ZZ(ii)) = K_V_Y;
    end
end

%%%%%%%%% Along Z %%%%%%%%%%%%%

XX = 1:Size(1);
YY = 1:Size(2);

XX = repmat(XX,1,Size(2));
XX = sortrows(XX');
YY = repmat(YY,1,Size(1))';

S_New_Z = zeros(Size(1),Size(2));

for ii = 1:length(XX);
    Vector = S(XX(ii),YY(ii),:);
    K_Z = find(Vector,1,Dir);
    K_V_Z = Vector(K_Z);
    Check = isempty(K_V_Z);
    if Check == 1;
        S_New_Z(XX(ii),YY(ii)) = 0;
    else
        S_New_Z(XX(ii),YY(ii)) = K_V_Z;
    end
end


SF_X = zeros(length(fieldList),1); SF_Y = zeros(length(fieldList),1); SF_Z = zeros(length(fieldList),1);

for i = 1:length(fieldList);
    
Ratio1_X = length(find(S_New_X == i)) / (Size(2) * Size(3));
SF_X(i) = Ratio1_X/Ratio_X(i);

Ratio1_Y = length(find(S_New_Y == i)) / (Size(1) * Size(3));
SF_Y(i) = Ratio1_Y/Ratio_Y(i);

Ratio1_Z = length(find(S_New_Z == i)) / (Size(1) * Size(2));
SF_Z(i) = Ratio1_Z/Ratio_Z(i);

end

SF_X = SF_X';
SF_Y = SF_Y';
SF_Z = SF_Z';
end

