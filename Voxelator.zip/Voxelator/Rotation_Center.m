function [dcm ] = Rotation_Center(theta,psi,phi)

% ##################### Credits ################################

% Prototype Version 1.0, created by
% Piyush Mukesh Mehta on 15 Dec, 2015
 
% For Questions, please contact the author @
% piyushmukeshmehta@gmail.com

% Please give appropriate credit for any use or modifications of this
% version.

% Please Cite: Mehta et al., Computer Graphics for Space Debris, ICATT,
% Darmstadt, Germany, 2015.

% #############################################################

% dcm = [cosd(theta)*cosd(psi)    cosd(phi)*sind(psi)+sind(phi)*sind(theta)*cosd(psi)     sind(phi)*sind(psi)-cosd(phi)*sind(theta)*cosd(psi); ...
%       -cosd(theta)*sind(psi)    cosd(phi)*cosd(psi)-sind(phi)*sind(theta)*sind(psi)     sind(phi)*cosd(psi)+cosd(phi)*sind(theta)*sind(psi); ...
%        sind(theta)             -sind(phi)*cosd(theta)                                   cosd(phi)*cosd(theta)];
   
dcm = [cosd(theta)*cosd(psi) cosd(theta)*sind(psi) -sind(theta); ...
       -cosd(phi)*sind(psi)+sind(phi)*sind(theta)*cosd(psi) sind(phi)*sind(theta)*sind(psi)+cosd(phi)*cosd(psi) sind(phi)*cosd(theta); ...
       cosd(phi)*sind(theta)*cosd(psi)+sind(phi)*sind(psi) cosd(phi)*sind(theta)*sind(psi)-sind(phi)*cosd(psi) cosd(phi)*cosd(theta)];
end

