function [ X1, Y1, Z1, X2, Y2, Z2 ] = Rotation_Axis_Cone( theta, psi, phi, X_cy_c, Y_cy_c, Z_cy_c, L_cn )

% ##################### Credits ################################

% Prototype Version 1.0, created by
% Piyush Mukesh Mehta on 15 Dec, 2015
 
% For Questions, please contact the author @
% piyushmukeshmehta@gmail.com

% Please give appropriate credit for any use or modifications of this
% version.

% Please Cite: Mehta et al., Computer Graphics for Space Debris, ICATT,
% Darmstadt, Germany, 2015.

% #############################################################

UVec = [-1 0 0];
% dcm = [cosd(theta)*cosd(psi)    cosd(phi)*sind(psi)+sind(phi)*sind(theta)*cosd(psi)     sind(phi)*sind(psi)-cosd(phi)*sind(theta)*cosd(psi); ...
%       -cosd(theta)*sind(psi)    cosd(phi)*cosd(psi)-sind(phi)*sind(theta)*sind(psi)     sind(phi)*cosd(psi)+cosd(phi)*sind(theta)*sind(psi); ...
%        sind(theta)             -sind(phi)*cosd(theta)                                   cosd(phi)*cosd(theta)];
   
dcm = [cosd(theta)*cosd(psi) cosd(theta)*sind(psi) -sind(theta); ...
       -cosd(phi)*sind(psi)+sind(phi)*sind(theta)*cosd(psi) sind(phi)*sind(theta)*sind(psi)+cosd(phi)*cosd(psi) sind(phi)*cosd(theta); ...
       cosd(phi)*sind(theta)*cosd(psi)+sind(phi)*sind(psi) cosd(phi)*sind(theta)*sind(psi)-sind(phi)*cosd(psi) cosd(phi)*cosd(theta)];
   
Axis = UVec * dcm;
Axis1 = -UVec * dcm;

X1 = (2/3) * L_cn * Axis1(1) + X_cy_c;
Y1 = (2/3) * L_cn * Axis1(2) + Y_cy_c;
Z1 = (2/3) * L_cn * Axis1(3) + Z_cy_c;

X2 = (1/3) * L_cn * Axis(1) + X_cy_c;
Y2 = (1/3) * L_cn * Axis(2) + Y_cy_c;
Z2 = (1/3) * L_cn * Axis(3) + Z_cy_c;

end

