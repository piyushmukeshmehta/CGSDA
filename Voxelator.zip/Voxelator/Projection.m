function [Ratio_X,Ratio_Y,Ratio_Z] = Projection(i)

% ##################### Credits ################################

% Prototype Version 1.0, created by
% Piyush Mukesh Mehta on 15 Dec, 2015
 
% For Questions, please contact the author @
% piyushmukeshmehta@gmail.com

% Please give appropriate credit for any use or modifications of this
% version.

% Please Cite: Mehta et al., Computer Graphics for Space Debris, ICATT,
% Darmstadt, Germany, 2015.

% #############################################################

global Output;

Size = size(Output);

[X,N] = find(Output(:,:,:,i) ~= 0);
N_Temp = N / Size(2);
Z = floor(N_Temp);
Y = N - Z * Size(2);

Proj_X = zeros(Size(2),Size(3));
Proj_Y = zeros(Size(1),Size(3));
Proj_Z = zeros(Size(1),Size(2));

Proj_X(sub2ind(size(Proj_X),Y,Z)) = i;
Proj_Y(sub2ind(size(Proj_Y),X,Z)) = i;
Proj_Z(sub2ind(size(Proj_Z),X,Y)) = i;

Ratio_X = length(find(Proj_X == i)) / (Size(2)*Size(3));
Ratio_Y = length(find(Proj_Y == i)) / (Size(1)*Size(3));
Ratio_Z = length(find(Proj_Z == i)) / (Size(1)*Size(2));

end

