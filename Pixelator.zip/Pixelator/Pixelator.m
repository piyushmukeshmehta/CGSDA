%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                                       %
%                                                                                       %
%                                       Pixelator                                       %
%                                                                                       %
%                                              created by Piyush M. Mehta, Dec 1 2015   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% JSK

% The tool is a faster alternative to the standard ray tracer. It takes an stl triangle
% mesh in the ascii format and returns the triangles that are visible from the given
% direction

% Distributed under terms of GNU General Public License. Please see
% Copyright file in the directory

% Inputs: 1) stl mesh
%         2) viewing direction
%         3) Screenshot resolution (optimize between accuracy and computation time)
%
% Outputs: Triangles (IDs) that are visible

%If you use Pixelator in any program or publication, please acknowledge
%its authors by adding a reference to: Piyush M. Mehta, Gonzalo Blanco-Arnao, Davide Bonetti, et al., 
%?Computer Graphics for Space Debris?, 6th International Conference on Astrodynamics Tools and Techniques,
%Darmstadt, Germany, 14-17 March, 2016.

% You can contact the author at piyushmukeshmehta@gmail.com for any
% questions or comments.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Inputs %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Read in the stl file to give Vertices, Faces, and Normals
[V,F,N] = import_stl_fast('Upper_Stage.stl',1);

% Compute the Area of the triangles. Not necessary for the tool but can be useful for various applications
A = Area(F,V);

% Viewing Direction
Direction = [0 40 30]; %http://uk.mathworks.com/help/matlab/ref/view.html
% Vecloity Vector, [Roll (about X), Pitch (about Y), Yaw (about Z)] for flight dynamics applications
Vinf = Velocity_Direction(Direction(1), Direction(2), Direction(3));

% Pixel Resolution of screenshot
Res = 6;    % x100 pixels

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Number of triangles in the mesh, used to define random unique colors on RGB spectrum
No_of_triangles = length(N(:,1));

%%%%%%%%%%%%%%%%% Generate and assign set of distinguishable colors %%%%%%%%%%%%%%%%%%
Colors1 = unique(randi([0,255],round(No_of_triangles*1.01),3),'rows');
Colors1 = Colors1(1:No_of_triangles,:);
Colors1(:,4) = 1:No_of_triangles; 
Colors(:,1:3) = Colors1(:,1:3)/255;

figure(1)
set(gcf,'color','w');%,'visible', 'off');
h = trisurf_3dpatch(F,V(:,1),V(:,2),V(:,3),Colors(:,1:3));
view(-Vinf);
axis equal;
set(gca, 'visible', 'off')
% set(h,'edgecolor','white','linewidth',1.0)

%%%%%%%%%%%%%%%%%%%%%%%% Setup the Screen for Capture %%%%%%%%%%%%%%%%%%%%%%%%
set(gcf,'PaperUnits','inches','PaperPosition',[0 0 Res Res])
rgb = hardcopy(gcf, '-Dopengl', '-r100');

%%%%%%%%%%%%%%%%%%%%%%%% Read the RGB data from the screenshot
%%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Size_rgb = size(rgb);
rgb1 = unique(reshape(rgb,Size_rgb(1)*Size_rgb(2),3),'rows');
rgb1 = rgb1(2:end-1,:);     % removing the RGB vector for the white background

%%%%%%% Identify unique RGB vector from the pixel data %%%%%%%%%%%%%

id_vis = zeros(length(rgb1(:,1)),1);
k1=1;
C_F = [0 0 0];

for ii = 1:length(rgb1(:,1));
    
    id = find(rgb1(ii,1) == Colors1(:,1) & rgb1(ii,2) == Colors1(:,2) & rgb1(ii,3) == Colors1(:,3));    
    if id ~= 0;
        id_vis(k1,1) = id;
        [C] = New_pre(Vinf,N(id,:),A(id,1));
        C_F = C_F + C;
        k1=k1+1;
    end
end
id_vis = unique(id_vis);

%%%%%%%%%%%%%%% View the Visible Triangles %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% Only for testing, turn off for actual analysis
%%%%%%%%%%%%%%% %%%%%%%%%%%%%

figure(2)
set(gcf,'color','w');
h1 = trisurf_3dpatch(F(id_vis,:),V(:,1),V(:,2),V(:,3),Colors(id_vis,1:3));
view(-Vinf);
axis equal;
set(gca, 'visible', 'off')




