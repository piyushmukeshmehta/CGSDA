function [C] = New_pre(Dir_Vec,Normal,Pix_Area)
    
Dot_pro = Dir_Vec*Normal';

Cp = 2.0*(Dot_pro)^2;

C = (Cp * Pix_Area) * Normal;

end
