function [ Vinf ] = Velocity_Direction( phi, theta, psi )

UVec = [-1 0 0];
% dcm = [cosd(theta)*cosd(psi)    cosd(phi)*sind(psi)+sind(phi)*sind(theta)*cosd(psi)     sind(phi)*sind(psi)-cosd(phi)*sind(theta)*cosd(psi); ...
%       -cosd(theta)*sind(psi)    cosd(phi)*cosd(psi)-sind(phi)*sind(theta)*sind(psi)     sind(phi)*cosd(psi)+cosd(phi)*sind(theta)*sind(psi); ...
%        sind(theta)             -sind(phi)*cosd(theta)                                   cosd(phi)*cosd(theta)];

dcm = [cosd(theta)*cosd(psi) cosd(theta)*sind(psi) -sind(theta); ...
       -cosd(phi)*sind(psi)+sind(phi)*sind(theta)*cosd(psi) sind(phi)*sind(theta)*sind(psi)+cosd(phi)*cosd(psi) sind(phi)*cosd(theta); ...
       cosd(phi)*sind(theta)*cosd(psi)+sind(phi)*sind(psi) cosd(phi)*sind(theta)*sind(psi)-sind(phi)*cosd(psi) cosd(phi)*cosd(theta)];
                                                         
   
Vinf = UVec * dcm';


end

